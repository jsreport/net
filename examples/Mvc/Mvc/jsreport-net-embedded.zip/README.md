#jsreport embedded

> jsreport embedded is an adaption of standard on premise jsreport more suitable to run in embedded mode along with main `.net` or `java` process 

Preparation steps

1. clone jsreport master and do `npm install`
2. `npm shrinkwrap`
3. `npm install -g flatten-packages`
4. `flatten-packages`
5. copy files from this repository
