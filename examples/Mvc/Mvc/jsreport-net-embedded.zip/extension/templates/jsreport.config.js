﻿module.exports = {
  "name": "templates",
  "main": "lib/templates.js",
  "embeddedSupport":true
}