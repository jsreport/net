﻿module.exports = {
  "name": "scripts",
  "main": "lib/scripts.js",
  "dependencies": [ "templates", "data" ]
}