﻿module.exports = {
  "name": "text",
  "dependencies": [ "templates" ],
  "main": "lib/text.js",
  "embeddedSupport":true
}