﻿module.exports = {
  "name": "images",
  "main": "lib/images.js",
  "dependencies": [ "templates" ]
}