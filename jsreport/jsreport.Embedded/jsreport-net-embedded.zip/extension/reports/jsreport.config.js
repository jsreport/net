﻿module.exports = {
  "name": "reports",
  "main": "lib/reports.js",
  "dependencies": [ "templates" ]
}