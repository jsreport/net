﻿module.exports = {
  "name": "client-html",
  "main": "lib/main.js",
  "embeddedSupport":true
}